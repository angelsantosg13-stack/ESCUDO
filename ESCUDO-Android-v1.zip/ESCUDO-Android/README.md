# ESCUDO Android v1

Aplicación Android nativa en Kotlin + Jetpack Compose para revisar mensajes, enlaces y códigos QR con señales heurísticas locales.

## Funciones incluidas
- Analizador local de mensajes y enlaces.
- Detección heurística de lenguaje urgente, solicitudes de credenciales, premios inesperados, pagos, enlaces acortados, IPs y dominios internacionalizados.
- Escáner QR mediante Google Code Scanner (requiere Google Play Services; descarga el módulo al primer uso).
- Historial local de hasta 30 análisis.
- Consejos prácticos de seguridad.
- Interfaz colorida y adaptable.

## Limitaciones importantes
ESCUDO no consulta reputación de dominios en tiempo real, no usa Google Safe Browsing ni garantiza que una URL sea segura. Un resultado de riesgo bajo no significa que un enlace sea confiable. No abre los enlaces analizados. El texto se analiza localmente y el historial queda en el almacenamiento privado de la app.

## Compilar
Requiere JDK 17, Android SDK 35 y Gradle 8.9:
`gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`
