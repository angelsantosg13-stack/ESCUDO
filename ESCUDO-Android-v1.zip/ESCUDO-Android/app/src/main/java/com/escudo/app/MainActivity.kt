package com.escudo.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.code.Scanner
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.android.gms.codescanner.GmsBarcodeScanning
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF18223A)
private val Blue = Color(0xFF4169E1)
private val Teal = Color(0xFF21B6A8)
private val Coral = Color(0xFFFF786B)
private val Pale = Color(0xFFF3F6FC)
private val Ink = Color(0xFF202A3D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp(this) }
    }
}

data class ScanResult(
    val input: String,
    val title: String,
    val risk: String,
    val score: Int,
    val reasons: List<String>,
    val time: String
)

@Composable
fun EscudoApp(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("escudo", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("Inicio") }
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var showInfo by remember { mutableStateOf(false) }

    fun analyze(value: String) {
        val clean = value.trim()
        if (clean.isBlank()) return
        val reasons = mutableListOf<String>()
        val lower = clean.lowercase(Locale.ROOT)
        var score = 0
        val urlRegex = Regex("""(?i)\b((https?://|www\.)[^\s<>"']+|[a-z0-9-]+\.[a-z]{2,}(/[^\s]*)?)""")
        val foundUrl = urlRegex.find(clean)?.value
        if (foundUrl != null) {
            val normalized = if (foundUrl.startsWith("http", true)) foundUrl else "https://$foundUrl"
            val host = runCatching { Uri.parse(normalized).host?.lowercase(Locale.ROOT) }.getOrNull().orEmpty()
            if (host.isBlank()) { score += 25; reasons.add("No se pudo interpretar correctamente el dominio.") }
            if (host.matches(Regex("""\d{1,3}(\.\d{1,3}){3}"""))) { score += 25; reasons.add("El enlace usa una dirección IP en lugar de un dominio habitual.") }
            if (host.startsWith("xn--") || host.contains(".xn--")) { score += 20; reasons.add("El dominio contiene caracteres internacionalizados que pueden imitar otros sitios.") }
            if (listOf("bit.ly", "tinyurl.com", "t.co", "cutt.ly", "rb.gy", "ow.ly").any { host == it || host.endsWith(".$it") }) {
                score += 18; reasons.add("Es un enlace acortado: oculta el destino final.")
            }
            if (normalized.contains("@")) { score += 25; reasons.add("El enlace contiene un formato que puede ocultar el destino real.") }
            if (host.count { it == '-' } >= 3) { score += 10; reasons.add("El dominio contiene varios guiones, una señal que conviene revisar.") }
            if (listOf(".zip", ".mov", ".click", ".top", ".xyz").any { host.endsWith(it) }) {
                score += 8; reasons.add("La terminación del dominio merece una revisión adicional.")
            }
            if (host.isNotBlank()) reasons.add("Dominio detectado: $host")
        } else {
            reasons.add("No se detectó un enlace web claro; se revisó el texto del mensaje.")
        }

        val urgency = listOf("urgente", "inmediatamente", "último aviso", "ultima oportunidad", "suspend", "bloque", "24 horas", "hoy mismo", "actúa ahora", "actua ahora")
        if (urgency.any { lower.contains(it) }) { score += 15; reasons.add("El mensaje utiliza lenguaje de urgencia o amenaza.") }
        val credential = listOf("contraseña", "contrasena", "password", "código de verificación", "codigo de verificacion", "nip", "token", "datos bancarios")
        if (credential.any { lower.contains(it) }) { score += 20; reasons.add("Solicita o menciona credenciales, códigos o datos bancarios.") }
        val prize = listOf("ganaste", "has ganado", "premio", "regalo", "recompensa", "sorteo")
        if (prize.any { lower.contains(it) }) { score += 12; reasons.add("Promete un premio o recompensa inesperada.") }
        val payment = listOf("paga", "deposit", "depósito", "transferencia", "multa", "paquete retenido")
        if (payment.any { lower.contains(it) }) { score += 10; reasons.add("Incluye una solicitud de pago o transferencia.") }
        score = score.coerceIn(0, 100)
        val risk = when {
            score >= 55 -> "ALTO"
            score >= 25 -> "MEDIO"
            else -> "BAJO"
        }
        if (reasons.size == 1) reasons.add("No se encontraron señales frecuentes en la revisión básica.")
        val item = ScanResult(clean, if (foundUrl != null) "Análisis de enlace" else "Análisis de mensaje", risk, score, reasons, now())
        result = item
        history = (listOf(item) + history).take(30)
        saveHistory(prefs, history)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, secondary = Teal, background = Pale, surface = Color.White,
            onPrimary = Color.White, onBackground = Ink, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Inicio", "Analizar", "Historial", "Consejos").forEach { item ->
                        val icon = when(item) {
                            "Inicio" -> Icons.Default.Home
                            "Analizar" -> Icons.Default.Shield
                            "Historial" -> Icons.Default.History
                            else -> Icons.Default.Lightbulb
                        }
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(icon, contentDescription = item) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when(page) {
                    "Inicio" -> HomeScreen(
                        onAnalyze = { page = "Analizar" },
                        onHistory = { page = "Historial" },
                        onTips = { page = "Consejos" },
                        onInfo = { showInfo = true }
                    )
                    "Analizar" -> AnalyzeScreen(
                        input = input,
                        onInput = { input = it },
                        onAnalyze = { analyze(input) },
                        onScan = {
                            val scanner = GmsBarcodeScanning.getClient(activity)
                            scanner.startScan()
                                .addOnSuccessListener { barcode ->
                                    input = barcode.rawValue.orEmpty()
                                    if (input.isNotBlank()) analyze(input)
                                }
                        },
                        result = result,
                        onClear = { input = ""; result = null }
                    )
                    "Historial" -> HistoryScreen(history, onOpen = {
                        input = it.input; result = it; page = "Analizar"
                    }, onClear = {
                        history = emptyList(); saveHistory(prefs, history)
                    })
                    else -> TipsScreen()
                }
            }
        }
        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Entendido") } },
                title = { Text("Sobre ESCUDO") },
                text = { Text("ESCUDO realiza una revisión local de señales comunes de fraude. No consulta bases de reputación en tiempo real y no puede garantizar que un enlace sea seguro o malicioso. Ante dudas, no compartas códigos, contraseñas ni datos bancarios.") }
            )
        }
    }
}

@Composable
fun HomeScreen(onAnalyze: () -> Unit, onHistory: () -> Unit, onTips: () -> Unit, onInfo: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Blue, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Shield, null, tint = Color.White, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("ESCUDO", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Navy)
                    Text("Tu tranquilidad digital", color = Color.Gray, fontSize = 13.sp)
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onInfo) { Icon(Icons.Default.Info, "Información", tint = Blue) }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(28.dp)) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Navega con más confianza.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Revisa mensajes y enlaces sospechosos antes de abrirlos o compartir información.", color = Color(0xFFD9E2F7))
                    Button(onClick = onAnalyze, colors = ButtonDefaults.buttonColors(containerColor = Teal), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Security, null); Spacer(Modifier.width(8.dp)); Text("Analizar ahora")
                    }
                }
            }
        }
        item { Text("Herramientas rápidas", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickTile("Escanear QR", Icons.Default.QrCodeScanner, Teal, onAnalyze, Modifier.weight(1f))
                QuickTile("Revisar historial", Icons.Default.History, Coral, onHistory, Modifier.weight(1f))
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().clickable(onClick = onTips)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, null, tint = Coral, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Consejo de seguridad", fontWeight = FontWeight.Bold)
                        Text("Ningún banco debe pedirte tu NIP o contraseña por mensaje.", color = Color.Gray, fontSize = 13.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, click: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier = modifier.clickable(onClick = click), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(42.dp).background(color.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color)
            }
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun AnalyzeScreen(input: String, onInput: (String) -> Unit, onAnalyze: () -> Unit, onScan: () -> Unit, result: ScanResult?, onClear: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Centro de análisis", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Pega un mensaje, enlace o escanea un código QR.", color = Color.Gray)
        }
        item {
            OutlinedTextField(
                value = input, onValueChange = onInput, modifier = Modifier.fillMaxWidth(),
                minLines = 5, label = { Text("Pega aquí el mensaje o enlace") },
                placeholder = { Text("Ej. Tu cuenta será suspendida. Verifica aquí...") },
                shape = RoundedCornerShape(18.dp)
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onAnalyze, enabled = input.isNotBlank(), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Search, null); Spacer(Modifier.width(6.dp)); Text("Analizar")
                }
                OutlinedButton(onClick = onScan, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(6.dp)); Text("Escanear QR")
                }
            }
        }
        if (result != null) {
            item { ResultCard(result) }
            item {
                OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Nuevo análisis")
                }
            }
        }
        item {
            Text("La revisión es orientativa y se realiza en el dispositivo. No abras enlaces dudosos para probarlos.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun ResultCard(result: ScanResult) {
    val color = when(result.risk) { "ALTO" -> Coral; "MEDIO" -> Color(0xFFE5A12A); else -> Teal }
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (result.risk == "ALTO") Icons.Default.GppBad else Icons.Default.GppGood, null, tint = color, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(result.title, fontWeight = FontWeight.Bold, color = Navy)
                    Text("Riesgo ${result.risk}", color = color, fontWeight = FontWeight.Bold)
                }
                Text("${result.score}/100", fontSize = 20.sp, fontWeight = FontWeight.Black, color = color)
            }
            LinearProgressIndicator(progress = { result.score / 100f }, modifier = Modifier.fillMaxWidth(), color = color, trackColor = Pale)
            Text("Señales encontradas", fontWeight = FontWeight.Bold)
            result.reasons.forEach { reason ->
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.CheckCircle, null, tint = Teal, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(reason, fontSize = 13.sp, color = Ink)
                }
            }
            Text("Resultado orientativo: un riesgo bajo no garantiza que el contenido sea seguro.", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun HistoryScreen(history: List<ScanResult>, onOpen: (ScanResult) -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.padding(top = 20.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Historial", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("${history.size} análisis guardados en este dispositivo", color = Color.Gray, fontSize = 12.sp)
            }
            if (history.isNotEmpty()) TextButton(onClick = onClear) { Text("Borrar") }
        }
        if (history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.History, null, tint = Color.LightGray, modifier = Modifier.size(56.dp))
                    Text("Aún no hay análisis", color = Color.Gray)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(history) { item ->
                    Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(item) }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            val c = when(item.risk) { "ALTO" -> Coral; "MEDIO" -> Color(0xFFE5A12A); else -> Teal }
                            Icon(Icons.Default.Shield, null, tint = c, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.title, fontWeight = FontWeight.Bold)
                                Text(item.input, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, fontSize = 12.sp)
                                Text(item.time, color = Color.Gray, fontSize = 11.sp)
                            }
                            Text(item.risk, color = c, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TipsScreen() {
    val tips = listOf(
        "Nunca compartas tu NIP, contraseña ni códigos de verificación, aunque el mensaje parezca venir de tu banco.",
        "Entra a tu banco o servicio escribiendo su dirección oficial; no uses enlaces recibidos por SMS o mensajería.",
        "Desconfía de premios inesperados que exigen pagar envío, impuestos o una cuota para recibirlos.",
        "Activa la verificación en dos pasos y utiliza contraseñas únicas.",
        "Antes de escanear un QR, revisa el destino que muestra el teléfono. No continúes si no reconoces el sitio.",
        "Si recibes una petición urgente de dinero de un familiar, confirma por una llamada a un número conocido.",
        "Mantén Android y tus aplicaciones actualizados. Instala apps desde tiendas oficiales."
    )
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Aprende a protegerte", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Hábitos sencillos que reducen el riesgo de fraude.", color = Color.Gray)
        }
        items(tips) { tip ->
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.CheckCircle, null, tint = Teal)
                    Spacer(Modifier.width(12.dp))
                    Text(tip, color = Ink)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F0FF))) {
                Text("Si crees que compartiste datos bancarios, contacta de inmediato a tu banco usando su número oficial y cambia tus credenciales desde su aplicación o sitio oficial.", Modifier.padding(16.dp), color = Navy, fontWeight = FontWeight.Medium)
            }
        }
    }
}

fun now(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "MX")).format(Date())

fun saveHistory(prefs: android.content.SharedPreferences, history: List<ScanResult>) {
    val array = JSONArray()
    history.forEach {
        val obj = JSONObject()
        obj.put("input", it.input); obj.put("title", it.title); obj.put("risk", it.risk)
        obj.put("score", it.score); obj.put("time", it.time)
        val reasons = JSONArray(); it.reasons.forEach { r -> reasons.put(r) }
        obj.put("reasons", reasons); array.put(obj)
    }
    prefs.edit().putString("history", array.toString()).apply()
}

fun loadHistory(prefs: android.content.SharedPreferences): List<ScanResult> {
    return runCatching {
        val array = JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            val reasons = obj.getJSONArray("reasons")
            ScanResult(
                obj.getString("input"), obj.getString("title"), obj.getString("risk"),
                obj.getInt("score"), (0 until reasons.length()).map { reasons.getString(it) },
                obj.getString("time")
            )
        }
    }.getOrDefault(emptyList())
}
